package DS07_Main_201400875_�����;

public class DS07_Main_201400875_����� {

	public static void main(String[] args) {
		AppController appController = new AppController();
		appController.run();
	}
}


/*


*/