package DS08_201400875_������;

public class ArrayList<E extends Comparable<E>> implements Stack<E> {
	
	private static final int DEFAULT_CAPACITY = 5;
	
	private int _capacity;
	private int _size;
	private E[] _elements;
	
	public int capacity() {
		return this._capacity;
	}
	private void setCapacity(int newCapacity) {
		this._capacity = newCapacity;
	}
	@Override
	public int size() {
		return this._size;
	}
	private void setSize(int newSize) {
		this._size = newSize;
	}
	private E[] elements() {
		return this._elements;
	}
	private void setElements(E[] newElements) {
		this._elements = newElements;
	}
	
	public ArrayList() {
		this (ArrayList.DEFAULT_CAPACITY);
	}
	@SuppressWarnings("unchecked")
	public ArrayList(int givenCapacity) {
		this.setCapacity(givenCapacity);
		this.setElements((E[]) new Comparable[this.capacity()]);
	}
	
	private void makeRoomAt(int aPosition) {
		for(int i = this.size(); i > aPosition; i--) {
			this.elements()[i] = this.elements()[i-1];
		}
	}
	private void removeGapAt(int aPosition) {
		for(int i = aPosition + 1; i < this.size(); i++) {
			this.elements()[i-1] = this.elements()[i];
		}
		this.elements()[this.size()-1] = null;
	}
	
	@Override 
	public boolean isEmpty() {
		return (this._size == 0);
	}
	@Override
	public boolean isFull() {
		return (this._size == this._capacity);
	}
	@Override
	public boolean push(E anElement) {
		return this.addToLast(anElement);
	}
	@Override
	public E pop() {
		return this.removeLast();
	}
	@Override
	public E peek() {
		if (this.isEmpty()) {
			return null;
		}
		else {
			return this.elementAt(this.size()-1); // Last element
		}
	}
	@Override
	public void clear() {		
	}
	
	public boolean doesContain(E anElement) {
		return(this.orderOf(anElement) >= 0);
	}
	public int orderOf(E anElement) {
		int order = -1;
		for(int index = 0; index < this.size() && order < 0; index++) {
			if(this.elements()[index].equals(anElement)) {
				order = index;
			}
		}
		return order;
	}
	public E elementAt(int anOrder) {
		if(anOrder < 0 || anOrder >= this.size()) {
			return null;
		}
		else { 
			return this.elements()[anOrder];
		}
	}
	public void setElementAt(int anOrder, E anElement) {
		if(anOrder < 0 || anOrder >= this.size()) {
			return ;
		}
		else {
			this.elements()[anOrder] = anElement;
		}
	}
	public boolean addTo(int anOrder, E anElement) {
		if(this.isFull()) {
			return false;
		}
		else if(anOrder < 0 || anOrder > this.size()) {
			return false;
		}
		else {
			this.makeRoomAt(anOrder);
			this.elements()[anOrder] = anElement;
			this.setSize(this.size()+1);
			return true;
		}
	}
	public boolean addToFirst(E anElement) {
		if(this.isFull()) {
			return false;
		}
		else {
			this.makeRoomAt(0);
			this.elements()[0] = anElement;
			this.setSize(this.size()+1);
			return true;
		}
	}
	public boolean addToLast(E anElement) {
		if(this.isFull()) {
			return false;
		}
		else {
			this.elements()[this.size()] = anElement;
			this.setSize(this.size()+1);
			return true;
		}
	}
	public E removeFrom(int anOrder) {
		if(anOrder < 0 || anOrder >= this.size()) {
			return null;
		}
		else {
			E removedElement = this.elements()[anOrder];
			this.removeGapAt(anOrder);
			this.setSize(this.size()-1);
			return removedElement;
		}
	}
	public E removeFirst() {
		if(this.isEmpty()) {
			return null;
		}
		else {
			E removedElement = this.elements()[0];
			this.removeGapAt(0);
			this.setSize(this.size()-1);
			return removedElement;
		}
	}
	public E removeLast() {
		if(this.isEmpty()) {
			return null;
		}
		else {
			E removedElement = this.elements()[this.size()-1];
			this.setSize(this.size()-1);
			return removedElement;
		}
	}
}
